package org.springboot.insurancemanagementsystem.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springboot.insurancemanagementsystem.dto.*;
import org.springboot.insurancemanagementsystem.entitie.*;
import org.springboot.insurancemanagementsystem.enums.ClaimStatus;
import org.springboot.insurancemanagementsystem.enums.PolicyStatus;
import org.springboot.insurancemanagementsystem.exception.BusinessException;
import org.springboot.insurancemanagementsystem.exception.ResourceNotFoundException;
import org.springboot.insurancemanagementsystem.repository.*;
import org.springboot.insurancemanagementsystem.service.ClaimService;
import org.springboot.insurancemanagementsystem.service.ClaimStatusHistoryService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClaimServiceImpl implements ClaimService {

    private final ClaimRepository claimRepository;
    private final PolicyRepository policyRepository;
    private final ClaimDocumentRepository claimDocumentRepository;
    private final CustomerRepository customerRepository;
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final ClaimStatusHistoryService historyService;

    @Override
    public ClaimResponseDto raiseClaim(
            ClaimRequestDto request,
            String customerEmail) {

        log.info("Customer {} attempting to raise claim for policyId={}",
                customerEmail,
                request.getPolicyId());

        Customer customer =
                customerRepository.findByUserEmail(customerEmail)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Customer not found"));

        Policy policy =
                policyRepository.findById(request.getPolicyId())
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Policy not found"));

        if (!policy.getCustomer().getId().equals(customer.getId())) {

            log.warn("Claim rejected. Policy {} does not belong to customer {}",
                    policy.getId(),
                    customerEmail);

            throw new BusinessException("Policy does not belong to customer");
        }

        if (policy.getStatus() != PolicyStatus.ACTIVE) {

            log.warn("Claim rejected. Policy {} is not ACTIVE",
                    policy.getPolicyNumber());

            throw new BusinessException("Claim can be raised only on active policy");
        }

        if (request.getClaimAmount()
                .compareTo(policy.getPlan().getCoverageAmount()) > 0) {

            log.warn("Claim amount {} exceeds coverage amount {}",
                    request.getClaimAmount(),
                    policy.getPlan().getCoverageAmount());

            throw new BusinessException("Claim amount exceeds coverage");
        }

        Claim claim = new Claim();
        claim.setClaimNumber(generateClaimNumber());
        claim.setPolicy(policy);
        claim.setClaimAmount(request.getClaimAmount());
        claim.setClaimReason(request.getClaimReason());
        claim.setIncidentDate(request.getIncidentDate());
        claim.setClaimStatus(ClaimStatus.SUBMITTED);
        claim.setCreatedAt(LocalDateTime.now());
        claim.setUpdatedAt(LocalDateTime.now());

        Claim savedClaim = claimRepository.save(claim);

        log.info("Claim {} raised successfully by customer {}",
                savedClaim.getClaimNumber(),
                customerEmail);

        List<ClaimDocument> savedDocs = new ArrayList<>();

        if (request.getDocuments() != null) {
            for (ClaimDocumentRequest d : request.getDocuments()) {
                savedDocs.add(
                        claimDocumentRepository.save(
                                ClaimDocument.builder()
                                        .claim(savedClaim)
                                        .documentName(d.getDocumentName())
                                        .documentType(d.getDocumentType())
                                        .documentReference(d.getDocumentReference())
                                        .uploadedDate(LocalDateTime.now())
                                        .build()
                        )
                );
            }
        }

        recordHistory(
                savedClaim,
                null,
                ClaimStatus.SUBMITTED,
                "Claim submitted by customer",
                customer.getUser()
        );

        return toClaimResponse(savedClaim, savedDocs);
    }

    @Override
    public ClaimResponseDto reviewClaim(
            Long claimId,
            ClaimReviewRequestDto request,
            String agentEmail) {

        log.info("Agent {} reviewing claimId={}", agentEmail, claimId);

        Claim claim = getClaimEntity(claimId);

        claim.setAgentRemarks(request.getRemarks());
        claim.setUpdatedAt(LocalDateTime.now());

        User agent = userRepository.findByEmail(agentEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Agent not found"));

        validateFinalStatus(claim);
        ClaimStatus oldStatus = claim.getClaimStatus();

        if (request.getRecommended()) {
            claim.setClaimStatus(ClaimStatus.RECOMMENDED_APPROVAL);
        } else {
            claim.setClaimStatus(ClaimStatus.RECOMMENDED_REJECTION);
        }

        Claim updatedClaim = claimRepository.save(claim);
        List<ClaimDocument> byClaimId = claimDocumentRepository.findByClaimId(updatedClaim.getId());

        historyService.recordStatusChange(claim, oldStatus, updatedClaim.getClaimStatus(), request.getRemarks(), agent);

        log.info("Claim {} reviewed by agent {}. Status changed from {} to {}",
                updatedClaim.getClaimNumber(), agentEmail, oldStatus, updatedClaim.getClaimStatus());

        return toEnhancedClaimResponse(updatedClaim, byClaimId);
    }

    @Override
    public ClaimResponseDto approveClaim(
            Long claimId,
            String remarks,
            String adminEmail) {

        log.info("Admin {} approving claimId={}", adminEmail, claimId);

        Claim claim = getClaimEntity(claimId);
        claim.setAdminRemarks(remarks);

        User admin = userRepository.findByEmail(adminEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found"));

        if (claim.getClaimStatus() != ClaimStatus.RECOMMENDED_APPROVAL) {
            log.warn("Claim {} cannot be approved. Current status={}", claim.getClaimNumber(), claim.getClaimStatus());
            throw new BusinessException("Claim not recommended for approval");
        }

        ClaimStatus oldStatus = claim.getClaimStatus();
        claim.setClaimStatus(ClaimStatus.APPROVED);
        claim.setUpdatedAt(LocalDateTime.now());

        Claim updatedClaim = claimRepository.save(claim);
        List<ClaimDocument> byClaimId = claimDocumentRepository.findByClaimId(updatedClaim.getId());

        historyService.recordStatusChange(claim, oldStatus, ClaimStatus.APPROVED, remarks, admin);

        log.info("Claim {} approved by admin {}", updatedClaim.getClaimNumber(), adminEmail);
        return toEnhancedClaimResponse(updatedClaim, byClaimId);
    }

    @Override
    public ClaimResponseDto rejectClaim(
            Long claimId,
            String remarks,
            String adminEmail) {

        log.info("Admin {} rejecting claimId={}", adminEmail, claimId);

        Claim claim = getClaimEntity(claimId);
        User admin = userRepository.findByEmail(adminEmail)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found"));

        validateFinalStatus(claim);

        ClaimStatus oldStatus = claim.getClaimStatus();
        claim.setAdminRemarks(remarks);
        claim.setClaimStatus(ClaimStatus.REJECTED);
        claim.setUpdatedAt(LocalDateTime.now());

        Claim updatedClaim = claimRepository.save(claim);
        historyService.recordStatusChange(claim, oldStatus, ClaimStatus.REJECTED, remarks, admin);

        log.info("Claim {} rejected by admin {}", updatedClaim.getClaimNumber(), adminEmail);
        List<ClaimDocument> byClaimId = claimDocumentRepository.findByClaimId(updatedClaim.getId());
        return toEnhancedClaimResponse(updatedClaim, byClaimId);
    }

    @Override
    public ClaimResponseDto getClaimById(Long claimId, String email, String role) {
        log.debug("Fetching claim by id={}", claimId);
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));

        if ("CUSTOMER".equals(role) && !claim.getPolicy().getCustomer().getUser().getEmail().equals(email)) {
            throw new BusinessException("Access denied. You can only view your own claims.");
        }

        return toEnhancedClaimResponse(claim, claimDocumentRepository.findByClaimId(claimId));
    }

    @Override
    public ClaimResponseDto getClaimByNumber(String claimNumber, String email, String role) {
        log.debug("Fetching claim by number={}", claimNumber);
        Claim claim = claimRepository.findByClaimNumber(claimNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found with number: " + claimNumber));

        if ("CUSTOMER".equals(role) && !claim.getPolicy().getCustomer().getUser().getEmail().equals(email)) {
            throw new BusinessException("Access denied. You can only view your own claims.");
        }

        return toEnhancedClaimResponse(claim, claimDocumentRepository.findByClaimId(claim.getId()));
    }

    @Override
    public List<ClaimResponseDto> getMyClaims(String customerEmail) {
        log.debug("Fetching claims for customer={}", customerEmail);
        List<Claim> claims = claimRepository.findByPolicyCustomerUserEmail(customerEmail);

        return claims.stream()
                .map(claim -> {
                    List<ClaimDocument> docs = claimDocumentRepository.findByClaimId(claim.getId());
                    return toClaimResponse(claim, docs); // Use standard to keep lists light
                })
                .collect(Collectors.toList());
    }

    @Override
    public Page<ClaimResponseDto> getAllClaims(
            int page,
            int size,
            String sortBy,
            String sortDir,
            String status) {

        log.debug("Fetching all claims page={}, size={}", page, size);
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Claim> claims;

        if (status != null && !status.isEmpty()) {
            claims = claimRepository.findByClaimStatus(ClaimStatus.valueOf(status), pageable);
        } else {
            claims = claimRepository.findAll(pageable);
        }

        // Use standard response for list views to prevent N+1 payload bloat
        return claims.map(claim -> toClaimResponse(claim, claimDocumentRepository.findByClaimId(claim.getId())));
    }

    private Claim getClaimEntity(Long claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));
    }

    private void validateFinalStatus(Claim claim) {
        if (claim.getClaimStatus() == ClaimStatus.APPROVED || claim.getClaimStatus() == ClaimStatus.REJECTED) {
            log.warn("Modification attempted on finalized claim {}", claim.getClaimNumber());
            throw new BusinessException("Approved or rejected claim cannot be modified");
        }
    }

    private String generateClaimNumber() {
        return "CLM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private void recordHistory(Claim claim, ClaimStatus previous, ClaimStatus next, String remarks, User by) {
        historyService.recordStatusChange(claim, previous, next, remarks, by);
    }

    private ClaimResponseDto toClaimResponse(Claim cl, List<ClaimDocument> docs) {
        Policy po = cl.getPolicy();
        Customer c = po != null ? po.getCustomer() : null;
        return ClaimResponseDto.builder()
                .claimId(cl.getId())
                .claimNumber(cl.getClaimNumber())
                .policyId(po != null ? po.getId() : null)
                .policyNumber(po != null ? po.getPolicyNumber() : null)
                .incidentDate(cl.getIncidentDate() != null ? cl.getIncidentDate().toString() : null)
                .customerName(c != null && c.getUser() != null ? c.getUser().getFullName() : null)
                .claimAmount(cl.getClaimAmount())
                .claimReason(cl.getClaimReason())
                .claimStatus(cl.getClaimStatus() != null ? cl.getClaimStatus().name() : null)
                .agentRemarks(cl.getAgentRemarks())
                .adminRemarks(cl.getAdminRemarks())
                .documents(docs == null
                        ? List.of()
                        : docs.stream()
                        .map(doc -> ClaimDocumentResponse.builder()
                                .claimDocumentId(doc.getId())
                                .documentName(doc.getDocumentName())
                                .documentType(doc.getDocumentType())
                                .documentReference(doc.getDocumentReference())
                                .uploadedDate(doc.getUploadedDate())
                                .build())
                        .toList())
                .build();
    }

    private ClaimResponseDto toEnhancedClaimResponse(Claim cl, List<ClaimDocument> docs) {
        ClaimResponseDto response = toClaimResponse(cl, docs);

        Policy po = cl.getPolicy();
        if (po != null) {
            PolicyPlan plan = po.getPlan();
            if (plan != null) {
                response.setPlanDetails(ClaimResponseDto.PlanDetailsDto.builder()
                        .planName(plan.getPlanName())
                        .coverageAmount(plan.getCoverageAmount())
                        .premiumAmount(plan.getPremiumAmount())
                        .premiumType(plan.getPremiumType() != null ? plan.getPremiumType().name() : null)
                        .duration(plan.getDuration())
                        .termsAndConditions(plan.getTermsAndConditions())
                        .build());
            }

            Customer customer = po.getCustomer();
            if (customer != null && customer.getUser() != null) {
                List<Claim> allCustomerClaims = claimRepository.findByPolicyCustomerUserEmail(customer.getUser().getEmail());

                List<ClaimResponseDto.ClaimHistoryDto> history = new ArrayList<>();
                int previousPlanClaimsCount = 0;
                double previousPlanClaimAmount = 0.0;

                for (Claim histClaim : allCustomerClaims) {
                    if (histClaim.getId().equals(cl.getId())) continue;

                    Policy histPolicy = histClaim.getPolicy();
                    PolicyPlan histPlan = histPolicy != null ? histPolicy.getPlan() : null;
                    String histPlanName = histPlan != null ? histPlan.getPlanName() : "N/A";
                    Double histCoverage = histPlan != null ? histPlan.getCoverageAmount() : 0.0;

                    history.add(ClaimResponseDto.ClaimHistoryDto.builder()
                            .claimNumber(histClaim.getClaimNumber())
                            .planName(histPlanName)
                            .coverageAmount(histCoverage)
                            .claimedAmount(histClaim.getClaimAmount())
                            .claimStatus(histClaim.getClaimStatus() != null ? histClaim.getClaimStatus().name() : null)
                            .claimDate(histClaim.getCreatedAt() != null ? histClaim.getCreatedAt().toString() : null)
                            .build());

                    if (plan != null && histPlan != null && plan.getId().equals(histPlan.getId())) {
                        previousPlanClaimsCount++;
                        if (histClaim.getClaimStatus() == ClaimStatus.APPROVED) {
                            previousPlanClaimAmount += (histClaim.getClaimAmount() != null ? histClaim.getClaimAmount() : 0.0);
                        }
                    }
                }

                history.sort((a, b) -> {
                    if (a.getClaimDate() == null && b.getClaimDate() == null) return 0;
                    if (a.getClaimDate() == null) return 1;
                    if (b.getClaimDate() == null) return -1;
                    return b.getClaimDate().compareTo(a.getClaimDate());
                });

                response.setCustomerClaimHistory(history);

                if (plan != null) {
                    double remaining = plan.getCoverageAmount() - previousPlanClaimAmount;
                    response.setPlanSummary(ClaimResponseDto.PlanSummaryDto.builder()
                            .totalPreviousClaims(previousPlanClaimsCount)
                            .totalPreviousClaimAmount(previousPlanClaimAmount)
                            .remainingCoverage(Math.max(remaining, 0.0))
                            .build());
                }
            }
        }
        return response;
    }
}