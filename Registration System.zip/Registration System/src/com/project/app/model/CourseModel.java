package com.project.app.model;

public class CourseModel {
    private final int courseId;
    private final String courseName;

    public CourseModel(int courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }

    public int getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }
}

